package com.api.billing.model.customer;

public enum SexType {

	MALE,
	FEMALE
	
}
