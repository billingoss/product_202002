package com.api.billing.model.product;

public class ProductPackageInput 
{
	private String mainProductId;

	public String getMainProductId() {
		return mainProductId;
	}

	public void setMainProductId(String mainProductId) {
		this.mainProductId = mainProductId;
	}
	
	

}
