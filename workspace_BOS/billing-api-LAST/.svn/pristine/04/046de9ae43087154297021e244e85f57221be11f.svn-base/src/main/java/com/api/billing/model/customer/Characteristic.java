package com.api.billing.model.customer;

public enum Characteristic {

	GENTEL,
	KIND,
	GENEROUS,
	AGGRESSIVE,
	RUDE
	
}
