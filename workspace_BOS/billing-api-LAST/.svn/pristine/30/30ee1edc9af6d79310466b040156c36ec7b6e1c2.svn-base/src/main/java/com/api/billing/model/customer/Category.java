package com.api.billing.model.customer;

public enum Category {

	PRODUCT,
	PRICE,
	DISCOUNT,
	INVOICE,
	PAYMENT,
	DELIVERY
	
}
