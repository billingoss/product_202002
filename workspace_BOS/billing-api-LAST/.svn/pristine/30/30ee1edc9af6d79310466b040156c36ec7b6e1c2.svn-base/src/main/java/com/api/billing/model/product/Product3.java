package com.api.billing.model.product;

public class Product3 
{
	private String productId;
	private String productName;
	private int providerNumber;
	private String productType;
	private String productState;
	private String subscribeStartDateTime;
	private String subscribeEndDateTime;
	private String recurringDeleveryYn;
	private String priceAmount;
	private String taxObjectYn;
	private String packageYn;
	private String packagePriceReferenceYn;
	private String packageVarietyYn;
	private String packagePriceBandwidth;
	private String productDescription;
	private String beforeProductId;
	private int suspendPriceAmount;
	private String exposureYn;
	private String lastChangeDateTime;
	/*ID mapping*/
	private String username;
	private int providernumber;
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public int getProvidernumber() {
		return providernumber;
	}
	public void setProvidernumber(int providernumber) {
		this.providernumber = providernumber;
	}
	/*ID mapping*/
	public String getProductId() {
		return productId;
	}
	public String getProductName() {
		return productName;
	}
	public int getProviderNumber() {
		return providerNumber;
	}
	public String getProductType() {
		return productType;
	}
	public String getProductState() {
		return productState;
	}
	public String getSubscribeStartDateTime() {
		return subscribeStartDateTime;
	}
	public String getSubscribeEndDateTime() {
		return subscribeEndDateTime;
	}
	public String getRecurringDeleveryYn() {
		return recurringDeleveryYn;
	}
	public String getPriceAmount() {
		return priceAmount;
	}
	public String getTaxObjectYn() {
		return taxObjectYn;
	}
	public String getPackageYn() {
		return packageYn;
	}
	public String getPackagePriceReferenceYn() {
		return packagePriceReferenceYn;
	}
	public String getPackageVarietyYn() {
		return packageVarietyYn;
	}
	public String getPackagePriceBandwidth() {
		return packagePriceBandwidth;
	}
	public String getProductDescription() {
		return productDescription;
	}
	public String getBeforeProductId() {
		return beforeProductId;
	}
	public int getSuspendPriceAmount() {
		return suspendPriceAmount;
	}
	public String getExposureYn() {
		return exposureYn;
	}
	public String getLastChangeDateTime() {
		return lastChangeDateTime;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public void setProviderNumber(int providerNumber) {
		this.providerNumber = providerNumber;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public void setProductState(String productState) {
		this.productState = productState;
	}
	public void setSubscribeStartDateTime(String subscribeStartDateTime) {
		this.subscribeStartDateTime = subscribeStartDateTime;
	}
	public void setSubscribeEndDateTime(String subscribeEndDateTime) {
		this.subscribeEndDateTime = subscribeEndDateTime;
	}
	public void setRecurringDeleveryYn(String recurringDeleveryYn) {
		this.recurringDeleveryYn = recurringDeleveryYn;
	}
	public void setPriceAmount(String priceAmount) {
		this.priceAmount = priceAmount;
	}
	public void setTaxObjectYn(String taxObjectYn) {
		this.taxObjectYn = taxObjectYn;
	}
	public void setPackageYn(String packageYn) {
		this.packageYn = packageYn;
	}
	public void setPackagePriceReferenceYn(String packagePriceReferenceYn) {
		this.packagePriceReferenceYn = packagePriceReferenceYn;
	}
	public void setPackageVarietyYn(String packageVarietyYn) {
		this.packageVarietyYn = packageVarietyYn;
	}
	public void setPackagePriceBandwidth(String packagePriceBandwidth) {
		this.packagePriceBandwidth = packagePriceBandwidth;
	}
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	public void setBeforeProductId(String beforeProductId) {
		this.beforeProductId = beforeProductId;
	}
	public void setSuspendPriceAmount(int suspendPriceAmount) {
		this.suspendPriceAmount = suspendPriceAmount;
	}
	public void setExposureYn(String exposureYn) {
		this.exposureYn = exposureYn;
	}
	public void setLastChangeDateTime(String lastChangeDateTime) {
		this.lastChangeDateTime = lastChangeDateTime;
	}
	
	

}
