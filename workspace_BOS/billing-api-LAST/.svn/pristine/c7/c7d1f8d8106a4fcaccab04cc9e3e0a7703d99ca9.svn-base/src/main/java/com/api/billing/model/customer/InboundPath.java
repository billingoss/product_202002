package com.api.billing.model.customer;

public enum InboundPath {

	PHONE,
	EMAIL,
	SNS,
	VISIT
	
}
