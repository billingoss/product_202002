package com.api.billing.model.customer;

public enum CustomerType {
	
	PERSON,
	CORPORATION

}
